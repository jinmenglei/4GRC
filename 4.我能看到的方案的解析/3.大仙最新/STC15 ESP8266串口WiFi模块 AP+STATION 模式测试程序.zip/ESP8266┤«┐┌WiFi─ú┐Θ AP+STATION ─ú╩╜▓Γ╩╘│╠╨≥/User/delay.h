#ifndef __DELAY_H_
#define __DELAY_H_

void DelayUS(int t);
void DelayMS(int t);

#endif